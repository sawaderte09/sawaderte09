import logging
import sqlite3
from datetime import datetime
from typing import Dict, List, Optional

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    filters,
    ContextTypes,
    ConversationHandler
)

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Константы для состояний
ADD_PRODUCT, DELETE_PRODUCT, ADD_MONEY, PRODUCT_NAME, PRODUCT_PRICE, PRODUCT_DESCRIPTION = range(6)

# ID администратора (замените на свой)
ADMIN_ID = 5008228898  # Ваш Telegram ID

# Ссылка на картинку для стартового сообщения (замените на свою)
START_IMAGE_URL = "https://github.com/sawaderte09/sawaderte09/blob/main/Gemini_Generated_Image_1z83ml1z83ml1z83_.png?raw=true"  # Ваша ссылка здесь

# База данных
class Database:
    def __init__(self, db_name: str = "bot_database.db"):
        self.conn = sqlite3.connect(db_name, check_same_thread=False)
        self.create_tables()
    
    def create_tables(self):
        cursor = self.conn.cursor()
        
        # Таблица пользователей
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                balance REAL DEFAULT 0.0,
                registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Таблица товаров
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                description TEXT,
                price REAL NOT NULL,
                is_active BOOLEAN DEFAULT 1
            )
        ''')
        
        # Таблица заказов
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                product_id INTEGER,
                status TEXT DEFAULT 'ожидание',
                order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (user_id),
                FOREIGN KEY (product_id) REFERENCES products (id)
            )
        ''')
        
        self.conn.commit()
    
    def get_user(self, user_id: int):
        cursor = self.conn.cursor()
        cursor.execute('SELECT * FROM users WHERE user_id = ?', (user_id,))
        return cursor.fetchone()
    
    def create_user(self, user_id: int, username: str):
        cursor = self.conn.cursor()
        cursor.execute(
            'INSERT OR IGNORE INTO users (user_id, username) VALUES (?, ?)',
            (user_id, username)
        )
        self.conn.commit()
    
    def update_balance(self, user_id: int, amount: float):
        cursor = self.conn.cursor()
        cursor.execute(
            'UPDATE users SET balance = balance + ? WHERE user_id = ?',
            (amount, user_id)
        )
        self.conn.commit()
    
    def get_balance(self, user_id: int):
        cursor = self.conn.cursor()
        cursor.execute('SELECT balance FROM users WHERE user_id = ?', (user_id,))
        result = cursor.fetchone()
        return result[0] if result else 0.0
    
    def add_product(self, name: str, description: str, price: float):
        cursor = self.conn.cursor()
        cursor.execute(
            'INSERT INTO products (name, description, price) VALUES (?, ?, ?)',
            (name, description, price)
        )
        self.conn.commit()
        return cursor.lastrowid
    
    def delete_product(self, product_id: int):
        cursor = self.conn.cursor()
        cursor.execute('DELETE FROM products WHERE id = ?', (product_id,))
        self.conn.commit()
        return cursor.rowcount > 0
    
    def get_active_products(self):
        cursor = self.conn.cursor()
        cursor.execute('SELECT * FROM products WHERE is_active = 1')
        return cursor.fetchall()
    
    def get_all_products(self):
        cursor = self.conn.cursor()
        cursor.execute('SELECT * FROM products')
        return cursor.fetchall()
    
    def get_product(self, product_id: int):
        cursor = self.conn.cursor()
        cursor.execute('SELECT * FROM products WHERE id = ?', (product_id,))
        return cursor.fetchone()
    
    def create_order(self, user_id: int, product_id: int):
        cursor = self.conn.cursor()
        cursor.execute(
            'INSERT INTO orders (user_id, product_id) VALUES (?, ?)',
            (user_id, product_id)
        )
        self.conn.commit()
        return cursor.lastrowid
    
    def get_pending_orders(self):
        cursor = self.conn.cursor()
        cursor.execute('''
            SELECT o.id, o.user_id, o.order_date, p.name, u.username 
            FROM orders o
            JOIN products p ON o.product_id = p.id
            JOIN users u ON o.user_id = u.user_id
            WHERE o.status = 'ожидание'
        ''')
        return cursor.fetchall()
    
    def update_order_status(self, order_id: int, status: str):
        cursor = self.conn.cursor()
        cursor.execute(
            'UPDATE orders SET status = ? WHERE id = ?',
            (status, order_id)
        )
        self.conn.commit()

# Инициализация базы данных
db = Database()

# Главное меню
def get_main_menu_keyboard(is_admin: bool = False):
    keyboard = [
        [InlineKeyboardButton("👤 Профиль", callback_data='profile')],
        [InlineKeyboardButton("🛒 Купить", callback_data='buy')],
        [InlineKeyboardButton("🆘 Тех Поддержка", callback_data='support')]
    ]
    
    if is_admin:
        keyboard.append([InlineKeyboardButton("⚙️ Админ Панель", callback_data='admin_panel')])
    
    return InlineKeyboardMarkup(keyboard)

# Админ панель
def get_admin_panel_keyboard():
    keyboard = [
        [InlineKeyboardButton("💰 Выдать деньги", callback_data='add_money')],
        [InlineKeyboardButton("📦 Новый товар", callback_data='add_product')],
        [InlineKeyboardButton("🗑️ Удалить товар", callback_data='delete_product')],
        [InlineKeyboardButton("📋 Открытые заказы", callback_data='pending_orders')],
        [InlineKeyboardButton("⬅️ Назад", callback_data='main_menu')]
    ]
    return InlineKeyboardMarkup(keyboard)

# Обработчики команд
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    db.create_user(user.id, user.username)
    
    # Отправляем картинку с подписью и кнопками
    welcome_text = f"""
    👋 Добро пожаловать, {user.first_name}!

    🤖 Я ваш персональный бот-магазин!

    🛒 Здесь вы можете:
    • Посмотреть свой профиль
    • Купить товары
    • Обратиться в поддержку

    👇 Выберите действие:
    """
    
    # Отправляем фото с кнопками
    await context.bot.send_photo(
        chat_id=update.effective_chat.id,
        photo=START_IMAGE_URL,
        caption=welcome_text,
        reply_markup=get_main_menu_keyboard(is_admin=(user.id == ADMIN_ID))
    )

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    data = query.data
    
    if data == 'main_menu':
        await start(update, context)
        return
    
    elif data == 'profile':
        user_data = db.get_user(user_id)
        if user_data:
            balance = db.get_balance(user_id)
            profile_text = f"""
            📊 **Ваш профиль:**
            
            👤 Имя: {query.from_user.first_name}
            📝 Username: @{query.from_user.username if query.from_user.username else 'не указан'}
            🆔 ID: {user_id}
            💰 Баланс: {balance:.2f} руб.
            📅 Регистрация: {user_data[3]}
            💵 Для пополнение обратитесь -> @qvntv
            """
            await query.edit_message_caption(
                caption=profile_text,
                reply_markup=get_main_menu_keyboard(is_admin=(user_id == ADMIN_ID))
            )
    
    elif data == 'buy':
        products = db.get_active_products()
        if not products:
            keyboard = [[InlineKeyboardButton("⬅️ Назад", callback_data='main_menu')]]
            await query.edit_message_caption(
                caption="😔 В магазине пока нет товаров",
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
            return
        
        keyboard = []
        for product in products:
            product_id, name, description, price, _ = product
            button_text = f"{name} - {price:.2f} руб."
            keyboard.append([InlineKeyboardButton(button_text, callback_data=f'buy_{product_id}')])
        
        keyboard.append([InlineKeyboardButton("⬅️ Назад", callback_data='main_menu')])
        
        await query.edit_message_caption(
            caption="🛒 **Выберите товар для покупки:**",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    
    elif data.startswith('buy_'):
        product_id = int(data.split('_')[1])
        product = db.get_product(product_id)
        
        if not product:
            await query.edit_message_caption(
                caption="❌ Товар не найден",
                reply_markup=get_main_menu_keyboard(is_admin=(user_id == ADMIN_ID))
            )
            return
        
        product_id, name, description, price, _ = product
        balance = db.get_balance(user_id)
        
        if balance >= price:
            # Создаем заказ
            order_id = db.create_order(user_id, product_id)
            
            # Уведомляем администратора
            admin_text = f"""
            🔔 **Новый заказ!**
            
            📝 Номер заказа: {order_id}
            👤 Пользователь: @{query.from_user.username}
            🆔 ID пользователя: {user_id}
            📦 Товар: {name}
            💰 Цена: {price:.2f} руб.
            ⏰ Время: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
            
            📨 Напишите пользователю: @{query.from_user.username}
            """
            
            try:
                await context.bot.send_message(
                    chat_id=ADMIN_ID,
                    text=admin_text
                )
            except:
                logger.error("Не удалось отправить сообщение администратору")
            
            # Обновляем баланс пользователя
            db.update_balance(user_id, -price)
            
            await query.edit_message_caption(
                caption=f"""
                ✅ **Заказ оформлен!**
                
                📦 Товар: {name}
                💰 Стоимость: {price:.2f} руб.
                🆔 Номер заказа: {order_id}
                
                ⚠️ **Внимание!** Администратор свяжется с вами в ближайшее время для выдачи товара.
                
                📨 Ваш username для связи: @{query.from_user.username}
                """,
                reply_markup=get_main_menu_keyboard(is_admin=(user_id == ADMIN_ID))
            )
        else:
            keyboard = [
                [InlineKeyboardButton("💰 Пополнить баланс", callback_data='add_money_user')],
                [InlineKeyboardButton("⬅️ Назад", callback_data='buy')]
            ]
            await query.edit_message_caption(
                caption=f"""
                ❌ **Недостаточно средств!**
                
                💰 Требуется: {price:.2f} руб.
                💵 Ваш баланс: {balance:.2f} руб.
                🔄 Не хватает: {price - balance:.2f} руб.
                """,
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
    
    elif data == 'support':
        support_text = """
        🆘 **Техническая поддержка:**
        
        Если у вас возникли проблемы:
        
        1. Опишите вашу проблему
        2. Укажите ваш ID: `{user_id}`
        3. Приложите скриншот (если нужно)
        
        📧 Связь: @qvntv
        ⏰ Время ответа: 1-24 часа
        """
        
        keyboard = [[InlineKeyboardButton("⬅️ Назад", callback_data='main_menu')]]
        await query.edit_message_caption(
            caption=support_text.format(user_id=user_id),
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    
    elif data == 'add_money_user':
        await query.edit_message_caption(
            caption="💰 Для пополнения баланса обратитесь к администратору: @qvntv",
            reply_markup=get_main_menu_keyboard(is_admin=(user_id == ADMIN_ID))
        )
    
    elif data == 'admin_panel':
        if user_id != ADMIN_ID:
            await query.edit_message_caption(
                caption="⛔ У вас нет доступа к админ панели",
                reply_markup=get_main_menu_keyboard(is_admin=False)
            )
            return
        
        admin_text = """
        ⚙️ **Админ Панель:**
        
        Здесь вы можете:
        • Выдать деньги пользователю
        • Добавить новый товар
        • Удалить товар
        • Просмотреть открытые заказы
        """
        
        await query.edit_message_caption(
            caption=admin_text,
            reply_markup=get_admin_panel_keyboard()
        )
    
    elif data == 'add_money':
        if user_id != ADMIN_ID:
            return
        
        await query.edit_message_caption(
            caption="💰 **Выдать деньги:**\n\nВведите ID пользователя и сумму через пробел:\nПример: `123456789 1000`",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Назад", callback_data='admin_panel')]])
        )
        return ADD_MONEY
    
    elif data == 'add_product':
        if user_id != ADMIN_ID:
            return
        
        await query.edit_message_caption(
            caption="📦 **Добавление нового товара:**\n\nВведите название товара:",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Назад", callback_data='admin_panel')]])
        )
        return PRODUCT_NAME
    
    elif data == 'delete_product':
        if user_id != ADMIN_ID:
            return
        
        products = db.get_all_products()
        if not products:
            keyboard = [[InlineKeyboardButton("⬅️ Назад", callback_data='admin_panel')]]
            await query.edit_message_caption(
                caption="📭 Нет товаров для удаления",
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
            return
        
        keyboard = []
        for product in products:
            product_id, name, _, price, _ = product
            button_text = f"❌ {name} - {price:.2f} руб."
            keyboard.append([InlineKeyboardButton(button_text, callback_data=f'delete_{product_id}')])
        
        keyboard.append([InlineKeyboardButton("⬅️ Назад", callback_data='admin_panel')])
        
        await query.edit_message_caption(
            caption="🗑️ **Выберите товар для удаления:**",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    
    elif data.startswith('delete_'):
        if user_id != ADMIN_ID:
            return
        
        product_id = int(data.split('_')[1])
        if db.delete_product(product_id):
            await query.edit_message_caption(
                caption=f"✅ Товар #{product_id} удален",
                reply_markup=get_admin_panel_keyboard()
            )
        else:
            await query.edit_message_caption(
                caption="❌ Не удалось удалить товар",
                reply_markup=get_admin_panel_keyboard()
            )
    
    elif data == 'pending_orders':
        if user_id != ADMIN_ID:
            return
        
        orders = db.get_pending_orders()
        if not orders:
            keyboard = [[InlineKeyboardButton("⬅️ Назад", callback_data='admin_panel')]]
            await query.edit_message_caption(
                caption="📭 Нет открытых заказов",
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
            return
        
        orders_text = "📋 **Открытые заказы:**\n\n"
        keyboard = []
        
        for order in orders:
            order_id, user_id_order, order_date, product_name, username = order
            orders_text += f"""
            🆔 Заказ: #{order_id}
            👤 Пользователь: @{username}
            🆔 ID: {user_id_order}
            📦 Товар: {product_name}
            ⏰ Время: {order_date}
            """
            keyboard.append([InlineKeyboardButton(f"✅ Выполнить заказ #{order_id}", callback_data=f'complete_{order_id}')])
        
        keyboard.append([InlineKeyboardButton("⬅️ Назад", callback_data='admin_panel')])
        
        await query.edit_message_caption(
            caption=orders_text,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    
    elif data.startswith('complete_'):
        if user_id != ADMIN_ID:
            return
        
        order_id = int(data.split('_')[1])
        db.update_order_status(order_id, 'выполнен')
        
        await query.edit_message_caption(
            caption=f"✅ Заказ #{order_id} отмечен как выполненный",
            reply_markup=get_admin_panel_keyboard()
        )

# Обработчики для админских действий
async def add_money_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id != ADMIN_ID:
        return ConversationHandler.END
    
    text = update.message.text.strip()
    
    try:
        parts = text.split()
        if len(parts) != 2:
            await update.message.reply_text(
                "❌ Неверный формат. Пример: `123456789 1000`\nПопробуйте снова:",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Отмена", callback_data='admin_panel')]])
            )
            return ADD_MONEY
        
        target_user_id = int(parts[0])
        amount = float(parts[1])
        
        if amount <= 0:
            await update.message.reply_text(
                "❌ Сумма должна быть больше 0",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Отмена", callback_data='admin_panel')]])
            )
            return ADD_MONEY
        
        # Обновляем баланс
        db.update_balance(target_user_id, amount)
        
        # Уведомляем пользователя
        try:
            await context.bot.send_message(
                chat_id=target_user_id,
                text=f"✅ Вам начислено {amount:.2f} руб.\n💰 Новый баланс: {db.get_balance(target_user_id):.2f} руб."
            )
        except:
            logger.warning(f"Не удалось уведомить пользователя {target_user_id}")
        
        await update.message.reply_text(
            f"✅ Пользователю {target_user_id} выдано {amount:.2f} руб.",
            reply_markup=get_admin_panel_keyboard()
        )
        
    except ValueError:
        await update.message.reply_text(
            "❌ Ошибка в данных. Убедитесь, что ID - число, а сумма - число с плавающей точкой\nПопробуйте снова:",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Отмена", callback_data='admin_panel')]])
        )
        return ADD_MONEY
    
    return ConversationHandler.END

async def product_name_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id != ADMIN_ID:
        return ConversationHandler.END
    
    context.user_data['product_name'] = update.message.text
    
    await update.message.reply_text(
        "📝 Введите описание товара:",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Отмена", callback_data='admin_panel')]])
    )
    return PRODUCT_DESCRIPTION

async def product_description_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id != ADMIN_ID:
        return ConversationHandler.END
    
    context.user_data['product_description'] = update.message.text
    
    await update.message.reply_text(
        "💰 Введите цену товара (только число):",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Отмена", callback_data='admin_panel')]])
    )
    return PRODUCT_PRICE

async def product_price_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id != ADMIN_ID:
        return ConversationHandler.END
    
    try:
        price = float(update.message.text)
        
        if price <= 0:
            await update.message.reply_text(
                "❌ Цена должна быть больше 0\nПопробуйте снова:",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Отмена", callback_data='admin_panel')]])
            )
            return PRODUCT_PRICE
        
        # Сохраняем товар в БД
        product_id = db.add_product(
            context.user_data['product_name'],
            context.user_data['product_description'],
            price
        )
        
        await update.message.reply_text(
            f"✅ Товар добавлен!\n\n"
            f"📦 Название: {context.user_data['product_name']}\n"
            f"📝 Описание: {context.user_data['product_description']}\n"
            f"💰 Цена: {price:.2f} руб.\n"
            f"🆔 ID товара: {product_id}",
            reply_markup=get_admin_panel_keyboard()
        )
        
        # Очищаем временные данные
        context.user_data.clear()
        
    except ValueError:
        await update.message.reply_text(
            "❌ Неверная цена. Введите число\nПопробуйте снова:",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Отмена", callback_data='admin_panel')]])
        )
        return PRODUCT_PRICE
    
    return ConversationHandler.END

async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    query = update.callback_query
    
    if query:
        await query.answer()
        if user_id == ADMIN_ID:
            await query.edit_message_caption(
                caption="⚙️ Админ Панель:",
                reply_markup=get_admin_panel_keyboard()
            )
        else:
            await start(update, context)
    else:
        if user_id == ADMIN_ID:
            await update.message.reply_text(
                "Действие отменено",
                reply_markup=get_admin_panel_keyboard()
            )
        else:
            await start(update, context)
    
    return ConversationHandler.END

# Основная функция
def main():
    TOKEN = "8530386797:AAHEZwIzp-odspzpJCdCr6KiDb-GguDwCJI"
    application = Application.builder().token(TOKEN).build()

    application.add_handler(CommandHandler("start", start))

    # ❗ ConversationHandler ДОЛЖЕН БЫТЬ ПЕРВЫМ
    conv_handler = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(button_handler, pattern='^(add_money|add_product)$')
        ],
        states={
            ADD_MONEY: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, add_money_handler),
            ],
            PRODUCT_NAME: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, product_name_handler),
            ],
            PRODUCT_DESCRIPTION: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, product_description_handler),
            ],
            PRODUCT_PRICE: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, product_price_handler),
            ],
        },
        fallbacks=[
            CallbackQueryHandler(cancel, pattern='^admin_panel$'),
            CommandHandler("start", start)
        ],
        allow_reentry=True
    )

    application.add_handler(conv_handler)

    # ❗ ОБЩИЙ handler кнопок — СТРОГО ПОСЛЕ
    application.add_handler(CallbackQueryHandler(button_handler))

    print("🤖 Бот запущен")
    application.run_polling()

    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()
