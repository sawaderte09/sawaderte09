# Конфигурационный файл

# Токен бота (получите у @BotFather)
BOT_TOKEN = "8530386797:AAHEZwIzp-odspzpJCdCr6KiDb-GguDwCJI"

# ID администратора
ADMIN_ID = 5008228898  # Замените на ваш Telegram ID

# Ссылка на картинку для стартового сообщения
START_IMAGE_URL = "https://github.com/sawaderte09/sawaderte09/blob/main/%D0%A1%D0%BD%D0%B8%D0%BC%D0%BE%D0%BA%20%D1%8D%D0%BA%D1%80%D0%B0%D0%BD%D0%B0%202025-11-18%20192514.png?raw=true"

# Название базы данных
DATABASE_NAME = "bot_database.db"
